<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar producto por C��digo de Barras</title>
    <script src="https://unpkg.com/@ericblade/quagga2@1.2.6/dist/quagga.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('FONDO WEB.png') no-repeat center center fixed;
            background-size: cover;
        }

        .espaciado-superior {
            padding-top: 250px;
        }

        .container {
            background-color: transparent;
            padding: 30px;
            border-radius: 10px;
            max-width: 600px;
            margin: auto;
        }

        .titulo-principal {
            text-align: center;
            font-size: 28px;
            font-weight: bold;
            color: white;
            text-shadow: 2px 2px 6px rgba(0, 0, 0, 0.7);
            margin-bottom: 30px;
        }

        .campo-centrado {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .campo-centrado .input-group {
            max-width: 400px;
            width: 100%;
            justify-content: center;
        }

        #reader {
            width: 100%;
            height: 250px;
            margin: 20px auto;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            background-color: #fff;
            position: relative;
        }

        #resultado {
            margin-top: 20px;
            padding: 15px;
            background-color: rgba(255, 255, 255, 0.85);
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        img {
            max-width: 100%;
            height: auto;
            margin-top: 10px;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

        .btn-buscar {
            margin-left: 10px;
        }

        .mensaje-exito {
            color: green;
            font-weight: bold;
            margin-top: 10px;
        }

        .btn-nuevo-producto {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            padding: 12px 18px;
            border-radius: 30px;
            font-size: 16px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        @media (max-width: 768px) {
            .espaciado-superior {
                padding-top: 160px;
            }
            .container {
                padding: 20px;
            }
            .titulo-principal {
                font-size: 22px;
            }
            .btn-nuevo-producto {
                font-size: 14px;
                padding: 10px 14px;
                bottom: 15px;
                right: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="espaciado-superior">
        <div class="container">
            <h1 class="titulo-principal">???? DoctorPet - Listado de Precios ????</h1>

            <div class="campo campo-centrado">
                <label class="font-weight-bold mb-2 text-white">Ingresar c��digo de barras:</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="manualInput" placeholder="Escribe o escanea el c��digo...">
                    <div class="input-group-append">
                        <button class="btn btn-primary btn-buscar" onclick="buscarManual()">Buscar</button>
                    </div>
                </div>
            </div>

            <div class="campo text-center mt-4">
                <button id="scanToggleBtn" class="btn btn-success mb-3" onclick="toggleScanner()">Escanear C��digo</button>
            </div>

            <div id="reader" style="display: none;"></div>
            <div id="resultado">Esperando escaneo o b��squeda...</div>
        </div>
    </div>

    <button class="btn btn-secondary btn-nuevo-producto" onclick="location.reload()">Buscar Nuevo Producto</button>

    <script>
        let isScanning = false;

        function mostrarProducto(data) {
            const res = document.getElementById("resultado");
            if (data.encontrado) {
                res.innerHTML = `
                    <h3>${data.Nombre}</h3>
                    <p><strong>SKU:</strong> ${data.SKU}</p>
                    <p><strong>C��digo de Barras:</strong> ${data.Codebar}</p>
                    <p><strong>Marca:</strong> ${data.Marca}</p>
                    <p><strong>Precio:</strong> $${data.Precio}</p>
                    <p><strong>Descripci��n:</strong> ${data.Descripcion}</p>
                    ${data.Imagen ? `<img src="${data.Imagen}" alt="${data.Nombre}">` : ""}
                    <p class="mensaje-exito">B��squeda Exitosa</p>
                `;
            } else {
                res.innerHTML = `<p>Producto no encontrado.</p>`;
            }
        }

        function buscarProducto(codigo) {
            fetch("buscar_producto.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: "codigo=" + encodeURIComponent(codigo)
            })
            .then(response => response.json())
            .then(data => mostrarProducto(data))
            .catch(error => {
                document.getElementById("resultado").innerHTML = `<p>Error al buscar: ${error}</p>`;
            });
        }

        function buscarManual() {
            const input = document.getElementById("manualInput").value.trim();
            if (input) {
                buscarProducto(input);
            }
        }

        function toggleScanner() {
            const readerDiv = document.getElementById("reader");
            const button = document.getElementById("scanToggleBtn");

            if (!isScanning) {
                readerDiv.style.display = "block";
                button.textContent = "Detener Escaneo";
                isScanning = true;

                Quagga.init({
                    inputStream: {
                        name: "Live",
                        type: "LiveStream",
                        target: readerDiv,
                        constraints: {
                            facingMode: "environment"
                        }
                    },
                    decoder: {
                        readers: ["ean_reader", "ean_8_reader", "code_128_reader", "upc_reader"]
                    }
                }, function(err) {
                    if (err) {
                        console.error("Error al acceder a la c��mara:", err);
                        document.getElementById("resultado").innerHTML = `<p>Error al acceder a la c��mara. Aseg��rate de dar permisos y estar en HTTPS.</p>`;
                        readerDiv.style.display = "none";
                        button.textContent = "Escanear C��digo";
                        isScanning = false;
                        return;
                    }
                    Quagga.start();
                });

                Quagga.onDetected(data => {
                    const codigo = data.codeResult.code;
                    document.getElementById("manualInput").value = codigo;
                    buscarProducto(codigo);

                    Quagga.stop();
                    Quagga.offDetected();
                    readerDiv.style.display = "none";
                    button.textContent = "Escanear C��digo";
                    isScanning = false;
                });

            } else {
                Quagga.stop();
                Quagga.offDetected();
                readerDiv.style.display = "none";
                button.textContent = "Escanear C��digo";
                isScanning = false;
            }
        }
    </script>
</body>
</html>


