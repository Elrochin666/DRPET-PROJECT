<?php
// Establecer la conexión a la base de datos
$servername = "localhost"; // Cambia esto si tu servidor de base de datos es diferente
$username = "root"; // Reemplaza con tu nombre de usuario de la base de datos
$password = ""; // **AÑADE AQUÍ LA CONTRASEÑA DE TU BASE DE DATOS (puede estar vacía "")**
$dbname = "drpet"; // Reemplaza con el nombre de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el código de barras enviado por POST
if (isset($_POST['codigo'])) {
    $codigo = $conn->real_escape_string($_POST['codigo']);

    // Consulta SQL para buscar el producto por código de barras
    $sql = "SELECT SKU, Nombre, Codebar, Precio, Marca, Descripcion, Imagen FROM productos WHERE Codebar = '$codigo'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Producto encontrado
        $row = $result->fetch_assoc();
        $response = array(
            'encontrado' => true,
            'SKU' => $row['SKU'],
            'Nombre' => $row['Nombre'],
            'Codebar' => $row['Codebar'],
            'Precio' => $row['Precio'],
            'Marca' => $row['Marca'],
            'Descripcion' => $row['Descripcion'],
            'Imagen' => $row['Imagen']
        );
    } else {
        // Producto no encontrado
        $response = array('encontrado' => false);
    }

    // Establecer el tipo de contenido a JSON
    header('Content-Type: application/json');

    // Devolver la respuesta como JSON
    echo json_encode($response);
} else {
    // Si no se envió el código de barras
    header('Content-Type: application/json');
    echo json_encode(array('error' => 'No se proporcionó el código de barras.'));
}

// Cerrar la conexión a la base de datos
$conn->close();
?>